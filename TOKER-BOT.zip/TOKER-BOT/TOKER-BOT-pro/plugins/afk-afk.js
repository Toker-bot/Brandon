let handler = async (m, { text }) => {
let user = global.db.data.users[m.sender]
user.afk = + new Date
user.afkReason = text
m.reply(`*EL USUARIO ${conn.getName(m.sender)} ESTARA INACTIVO (𝙰𝙵𝙺), PORFAVOR NO LO ETIQUETEN*\n\n*—◉ MOTIVO DE LA INACTIVIDAD (𝙰𝙵𝙺)${text ? ': ' + text : ''}*
`)}
handler.help = ['afk [alasan]']
handler.tags = ['main']
handler.command = /^afk$/i
export default handler
