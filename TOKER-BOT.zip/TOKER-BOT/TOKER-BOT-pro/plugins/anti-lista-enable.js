let handler = async (m, { conn, usedPrefix, command, args, isOwner, isAdmin, isROwner }) => {
const sections = [{
title: comando + 'comando para adm o el bot' + comando2,
rows: [
{title: "✨ ] welcome", description: "ACTIVA O DESACTIVA LA BIENVENIDA DEL GRUPO", rowId: `${usedPrefix + command} welcome`},
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "📚 ] MODO PUBLICO", description: "EL BOT AHORA ES USO PUBLICO Y/O PRIVADO", rowId: `${usedPrefix + command} public`},
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: 🔞] MODO HORNY", description: "ACTIVAR O DESACTIVA LOS COMANDOS +18", rowId: `${usedPrefix + command} modohorny`},
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "⚠️ ] ANTILINK", description: "ACTIVAR O DESACTIVAR EL ANTI ENLACES DE GRUPOS DE WHATSAAP ", rowId: `${usedPrefix + command} antilink`},   
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "⚠️ ] ANTILINK 2", description: "ACTIVAR O DESACTIVAR EL ANTI ENLACES QUE INICIAN EN HTTPS", rowId: `${usedPrefix + command} antilink2`},    
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "🥷 ] DECTECT", description: "ACTIVAR O DESACTIVAR LAS NOTIFICACIONES DE NUEVA MODIFICACIÓN EN UN GRUPO", rowId: `${usedPrefix + command} detect`},      
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "✋️ ] RESTRICT", description: "ACTIVAR O DESACTIVAR  LAS RESTRICCIONES PARA SACAR GENTE DE GRUPOS", rowId: `${usedPrefix + command} restrict`},    
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "✔️️ ] AUTOREAD", description: "MARCA AUTOMÁTICA LAS CONVERSACIONES COMO LEIDO", rowId: `${usedPrefix + command} autoread`},
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "🔊 ] AUDIOS", description: "ACTIVAR O DESACTIVAR LOS COMANDOS DE AUDIOS SIN PREFIJO", rowId: `${usedPrefix + command} audios`},
]},{
title: comando + 'ᴄᴏᴍᴀɴᴅᴏ ᴘᴀʀ ᴀᴅᴍɪɴ ᴏ ᴇʟ ᴘʀᴏᴘɪᴇᴛᴀʀɪᴏ' + comando2, 
rows: [
{title: "📲 ] AUTOSTICKER", description: "TODAS LAS IMAGENES, VIDEOS O ENLASES ENVIADOS SE CONVERTIRÁN EN STICKER", rowId: `${usedPrefix + command} autosticker`},
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "💬 ] PCONLYL", description: "EL BOT SOLO RESPONDERA A LOS COMANDOS SI ES UN CHAT PVD", rowId: `${usedPrefix + command} pconly`},
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "🚦 ] GCONLY", description: "EL BOT SOLO RESPONDERA A LOS COMANDOS DE LOS GRUPOS", rowId: `${usedPrefix + command} gconly`},
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "❌ ] ANTIVIEWONCE", description: "ACTIVAR O DESACTIVAR EL ANTI VER SOLO UNA VEZ", rowId: `${usedPrefix + command} antiviewonce`},
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "☎️ ] ANTILLAMADA", description: "ACTIVAR O DESACTIVAR EL ANTI LLAMADA", rowId: `${usedPrefix + command} anticall`},
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "📵 ] ANTIPRIVADO", description: "EL BOT BLOQUEARA ALOS USUARIOS QUE LE HABLEN AL PRIVADO", rowId: `${usedPrefix + command} antiprivado`},
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "☣️ ] ANTITOXIC", description: "ACTIVAR O DESACTIVAR EL ANTI MALA PALABRA", rowId: `${usedPrefix + command} antitoxic`},
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "️ 🔥] ANTITRABAS", description: "ACTIVAR O DESACTIVAR EL ANTI TRABAS", rowId: `${usedPrefix + command} antitraba`},
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "🚨 ] ANTIARABES", description: "AL ENVIAR MENSAJE UN NUMERO ARABE EL BOT LO FUNA DEL GRUPO", rowId: `${usedPrefix + command} antiarabes`}, 
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "🤖 ] MODEJADIBOT", description: "ACTIVAR O DESACTIVAR EL COMANDO PARA SUB BOTS (#SERBOR / #JADIBOT)", rowId: `${usedPrefix + command} modejadibot`}, 
]},{
title: comando + 'comando para adm o el bot' + comando2, 
rows: [
{title: "✅️ ] MODOADMIN", description: "EL BOT SOLO PUEDE RESPONDER A LOS ADMINS DEL GRUPO", rowId: `${usedPrefix + command} modoadmin`},    
]}, ]
let name = await conn.getName(m.sender)
const listMessage = {
text: ' ',
footer: `▭▬▭▬▭▬▭▬▭▬▭
┃   ◈ ✪𝚃𝙾𝙺𝙴𝚁-𝙱𝙾𝚃. ofc   ┃
╭▭▬▭▬▭▬▭▬▭▬▭
┃♧┃🥷HOLA${name}🌹✨
┃♧┃⚙️ajustes
┃♧┃🖲que quires desactivar
┃♧┃❌️desactivar | ✅️activar
┃♧┃✍🏼selecciona el comando
┃♧┃🔆puedes actualizarlo por el
┃♧┃📚propietario administrador del grupo
◈ ✪-𝙱𝙾𝚃┃
└────────────────`,
title: null,
buttonText: "𝐒𝐄𝐋𝐄𝐂𝐂𝐈𝐎𝐍𝐄 𝐀𝐐𝐔𝐢",
sections }

let isEnable = /true|enable|(turn)?on|1/i.test(command)
let chat = global.db.data.chats[m.chat]
let user = global.db.data.users[m.sender]
let bot = global.db.data.settings[conn.user.jid] || {}
let type = (args[0] || '').toLowerCase()
let isAll = false, isUser = false
switch (type) {
case 'welcome':
if (!m.isGroup) {
if (!isOwner) {
global.dfail('group', m, conn)
throw false
}
} else if (!isAdmin) {
global.dfail('admin', m, conn)
throw false
}
chat.welcome = isEnable
break
case 'detect':
if (!m.isGroup) {
if (!isOwner) {
global.dfail('group', m, conn)
throw false
}
} else if (!isAdmin) {
global.dfail('admin', m, conn)
throw false
}
chat.detect = isEnable
break
case 'delete':
if (m.isGroup) {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}}
chat.delete = isEnable
break
case 'antidelete':
if (m.isGroup) {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}}
chat.delete = !isEnable
break
case 'public':
isAll = true
if (!isROwner) {
global.dfail('rowner', m, conn)
throw false
}
global.opts['self'] = !isEnable
break
case 'antilink':
if (m.isGroup) {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}}
chat.antiLink = isEnable
break
case 'antilink2':
if (m.isGroup) {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}}
chat.antiLink2 = isEnable 
break
case 'antiviewonce':
if (m.isGroup) {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}}
chat.antiviewonce = isEnable 
break
case 'modohorny':
if (m.isGroup) {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}}
chat.modohorny = isEnable          
break
case 'modoadmin':
if (m.isGroup) {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}}
chat.modoadmin = isEnable          
break    
case 'autosticker':
if (m.isGroup) {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}}
chat.autosticker = isEnable          
break
case 'audios':
if (m.isGroup) {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}}
chat.audios = isEnable          
break
case 'restrict':
isAll = true
if (!isOwner) {
global.dfail('owner', m, conn)
throw false
}
bot.restrict = isEnable
break
case 'nyimak':
isAll = true
if (!isROwner) {
global.dfail('rowner', m, conn)
throw false
}
global.opts['nyimak'] = isEnable
break
case 'autoread':
isAll = true
if (!isROwner) {
global.dfail('rowner', m, conn)
throw false
}
global.opts['autoread'] = isEnable
break
case 'pconly':
case 'privateonly':
isAll = true
if (!isROwner) {
global.dfail('rowner', m, conn)
throw false
}
global.opts['pconly'] = isEnable
break
case 'gconly':
case 'grouponly':
isAll = true
if (!isROwner) {
global.dfail('rowner', m, conn)
throw false
}
global.opts['gconly'] = isEnable
break
case 'swonly':
case 'statusonly':
isAll = true
if (!isROwner) {
global.dfail('rowner', m, conn)
throw false
}
global.opts['swonly'] = isEnable
break
case 'anticall':
isAll = true
if (!isROwner) {
global.dfail('rowner', m, conn)
throw false
}
bot.antiCall = isEnable
break
case 'antiprivado':
isAll = true
if (!isROwner) {
global.dfail('rowner', m, conn)
throw false
}
bot.antiPrivate = isEnable
break
case 'modejadibot':
isAll = true
if (!isROwner) {
global.dfail('rowner', m, conn)
throw false
}
bot.modejadibot = isEnable
break        
case 'antitoxic':
if (m.isGroup) {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}}
chat.antiToxic = isEnable
break
case 'antitraba':
if (m.isGroup) {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}}
chat.antiTraba = isEnable
break
case 'antiarabes':
if (m.isGroup) {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}}
chat.antiArab = isEnable  
break
default:
if (!/[01]/.test(command)) return await conn.sendMessage(m.chat, listMessage)
throw false
}
conn.sendButton(m.chat, `📚OPCION: ${type} 
⚙️ESTADO: ${isEnable ? '𝙰𝙲𝚃𝙸𝚅𝙰𝙳𝙾' : '𝙳𝙴𝚂𝙰𝙲𝚃𝙸𝚅𝙰𝙳𝙾'}
🥷PARA: ${isAll ? 'ESTE BOT' : isUser ? '' : 'ESTE CHAT'}`, wm2, null, [[`${isEnable ? '❌DESACTIVAR ️' : '✅️ACTIVAR️️'}`, `${isEnable ? `#disable ${type}` : `#enable ${type}`}`]], m)}
handler.help = ['en', 'dis'].map(v => v + 'able <option>')
handler.tags = ['group', 'owner']
handler.command = /^((en|dis)able|(tru|fals)e|(turn)?[01])$/i
export default handler