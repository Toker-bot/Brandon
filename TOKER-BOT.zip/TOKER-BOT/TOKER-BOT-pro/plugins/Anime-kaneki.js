let handler = async (m, { conn, text, command }) => {
    let yh = global.kaneki
    let url = yh[Math.floor(Math.random() * yh.length)]
    conn.sendButton(m.chat, `Random kaneko- is cute `.trim(), author, url, [['🔜 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔜', `/${command}`]], m)
  }
  handler.command = /^(Kaneki|kaneki)$/i
  handler.tags = ['anime']
  handler.help = ['kaneki']
  export default handler
  
  global.kaneki = [
"https://imgur.com/2cggVOo.jpeg",
"https://imgur.com/a/u1NuRzG.jpeg",
"https://imgur.com/a/5zZNFRO.jpeg",
"https://imgur.com/a/shOA3eo.jpeg",
"https://imgur.com/a/Czhy78u.jpeg",
"https://imgur.com/YuB3W7R.jpeg",
"https://imgur.com/a/ugfaug5.jpeg",
"https://imgur.com/a/4WWNHrm.jpeg",
"https://imgur.com/XXSg3bs.jpeg",
"https://imgur.com/a/0gddOXB.jpeg",
"https://imgur.com/a/0T5eq7C.jpeg",
"https://imgur.com/yzGSZ4N.jpeg",
"https://imgur.com/a/S3KQFJL.jpeg",
]