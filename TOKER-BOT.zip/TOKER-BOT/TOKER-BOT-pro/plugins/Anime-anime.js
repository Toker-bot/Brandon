import axios from "axios"
let handler = async (m, {command, conn, usedPrefix}) => {
{await m.reply('📌 _Cargando..._\n▬▬▬▭▭▭▭▭')}
let res = (await axios.get(`https://youtube.com/@TokerBot-${command}.json`)).data  
let haha = await res[Math.floor(res.length * Math.random())]    
conn.sendButton(m.chat, `_${command}_`.trim(), author, haha, [['🔜 𝚂𝙸𝙶𝚄𝙸𝙴𝙽𝚃𝙴 🔜', `${usedPrefix + command}`]], m)    
}
handler.command = handler.help = ['kaneki', 'sakura', 'nezuko', 'naruto', 'messi', 'cosplay', 'cristianoronaldo, 'hacker', 'hinata', 'zaske', 'zero two',
handler.tags = ['anime']
export default handler