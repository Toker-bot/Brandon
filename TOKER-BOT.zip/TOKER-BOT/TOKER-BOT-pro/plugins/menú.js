import fs, { promises } from 'fs'
import fetch from 'node-fetch'
let handler = async (m, { conn, usedPrefix, usedPrefix: _p, __dirname, text }) => {
try {
let vn = './src/Miku/musica xd'
let pp = './src/foto requerida.jpg'
let img = await(await fetch('https://imgur.com/2cggVOo.jpeg')).buffer()
let d = new Date(new Date + 3600000)
let locale = 'es'
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' })
let _uptime = process.uptime() * 1000
let uptime = clockString(_uptime)
let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length 
let more = String.fromCharCode(8206)
let readMore = more.repeat(850)   
let taguser = '@' + m.sender.split("@s.whatsapp.net")[0]
let str = `╭▭▬▭▬▭▬▭▬▭▬▭
┃✪TOKER-BOT ┃
Hola Soy Toker:${tagusar}
◈ Numero:Wa.me/+526441187370
◈ fecha:${week}, ${date}
◈ usuarios:${rtotelreg}

╭▭▬▭▬▭▬▭▬▭▬▭
   𝐌𝐄𝐍𝐔 𝐃𝐄𝐋 𝐁𝐎𝐓
┃🎩 ꙰│/terminosycondiciones
┃🎩 ꙰│◈/grupos
┃🎩 ꙰│◈/estado
┃🎩 ꙰│◈/speebtest
┃🎩 ꙰│◈/donar
┃🎩 ꙰│◈/grouplist
┃🎩 ꙰│◈/owner
┃🎩 ꙰│◈/script
┃🎩 ꙰│◈ /bot (uso sin prefijo)
 
└▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃  「 OPTEN TU BOT 」
┃🎩 ꙰│◈/serbot 
┃🎩 ꙰│◈/stop
┃🎩 ꙰│◈ /bots
└▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃ 「ACTIVAR BOT O DESACTIVAR 」

┃🎩 ꙰│◈/enable-->walcome
┃🎩 ꙰│◈/bisable-->walcome
┃🎩 ꙰│◈/enable-->modohorny  
┃🎩 ꙰│◈/disable-->modohorny
┃🎩 ꙰│◈/enable-->antilink 
┃🎩 ꙰│◈ /disable-->antilink 
┃🎩 ꙰│◈/enable-->antilink2
┃🎩 ꙰│◈/enable-->antilink 2
┃🎩 ꙰│◈/enable-->detect
┃🎩 ꙰│◈/disable-->detect
┃🎩 ꙰│◈/enable-->audios 
┃🎩 ꙰│◈disable-->audios
┃🎩 ꙰│◈/enable-->autosticker
┃🎩 ꙰│◈/disable-->autosticker
┃🎩 ꙰│◈/enable-->antiviewonce
┃🎩 ꙰│◈/disable-->antiviewonce
┃🎩 ꙰│◈/enable-->antitoxic
┃🎩 ꙰│◈/disable-->antitoxic 
┃🎩 ꙰│◈/enable-->antitraba
┃🎩 ꙰│◈/disable-->antitraba
┃🎩 ꙰│◈/enable-->antiarabes
┃🎩 ꙰│◈/disable-->antiarabes
┃🎩 ꙰│◈/enable-->modoadmin
┃🎩 ꙰│◈/disable-->modoadmin
└▭▬▭▬▭▬▭▬▭▬▭

▭▬▭▬▭▬▭▬▭▬▭
┃ 「 DESCARGAS」
┃🎩 ꙰│◈/ytmp3-->enlase
┃🎩 ꙰│◈/ytmp3doc-->enlase
┃🎩 ꙰│◈/play-->texto
┃🎩 ꙰│◈/play.1-->texto
┃🎩 ꙰│◈/play.2-->texto
┃🎩 ꙰│◈/playdoc--texto
┃🎩 ꙰│◈/playlist-->texto
┃🎩 ꙰│◈/playlist2-->texto
┃🎩 ꙰│◈/spotify
┃🎩 ꙰│◈/ytmp4-->enlase
┃🎩 ꙰│◈/ytmp4doc-->enlase
┃🎩 ꙰│◈/dapk2-->enlase
┃🎩 ꙰│◈/fb-->enlase
┃🎩 ꙰│◈/fb2-->enlase
┃🎩 ꙰│◈/fb3-->enlase
┃🎩 ꙰│◈/fb4-->enlase
┃🎩 ꙰│◈/fb5-->enlase
┃🎩 ꙰│◈/instagram-->enlase
┃🎩 ꙰│◈/instagram2-->enlase
┃🎩 ꙰│◈/instagram3-->enlase
┃🎩 ꙰│◈/mediafire-->enlase
┃🎩 ꙰│◈/gitclone-->enlase
┃🎩 ꙰│◈/gdrive-->enlase
┃🎩 ꙰│◈/tiktok-->enlase
┃🎩 ꙰│◈/xnxxdl-->enlase
┃🎩 ꙰│◈/xvideosdl-->enlase
┃🎩 ꙰│◈/Twitter-->enlase
┃🎩 ꙰│◈/stickerpack-->enlase
┃🎩 ꙰│◈/stickerly-->enlase
┃🎩 ꙰│◈/ringtone-->texto
┃🎩 ꙰│◈/soundcloud-->texto
┃🎩 ꙰│◈/imagen-->texto
┃🎩 ꙰│◈/pinturest-->texto
┃🎩 ꙰│◈/wallpaper1-->texto
┃🎩 ꙰│◈/wallpaper2-->texto
┃🎩 ꙰│◈/pptiktok-->nombre de usuario 
┃🎩 ꙰│◈/igstalk-->nombre de usuario 
┃🎩 ꙰│◈/igstory-->nombre de usuario 
┃🎩 ꙰│◈/tiktokstalk-->username
└▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃ 「 OPCION PARA GRUPOS 」
┃🎩 ꙰│◈/kick-->@tag
┃🎩 ꙰│◈/kick-->@tag
┃🎩 ꙰│◈/kicknum-->texto 
┃🎩 ꙰│◈/listanum-->texto
┃🎩 ꙰│◈/grupo-->abrir-->cerrar
┃🎩 ꙰│◈/grouptime-->opcion-->tiempo
┃🎩 ꙰│◈/promote-->@tag
┃🎩 ꙰│◈/demote-->@tag
┃🎩 ꙰│◈/infogroup
┃🎩 ꙰│◈/resetlink
┃🎩 ꙰│◈/link
┃🎩 ꙰│◈/setname-->texto
┃🎩 ꙰│◈/setdesc-->texto 
┃🎩 ꙰│◈/invocar-->texto
┃🎩 ꙰│◈/setwelcome-->texto 
┃🎩 ꙰│◈/setbye--texto
┃🎩 ꙰│◈/hidetag-->texto
┃🎩 ꙰│◈/hidetag-->audio
┃🎩 ꙰│◈/hidetag-->video
┃🎩 ꙰│◈/hidetag-->imagen
┃🎩 ꙰│◈/warn-->@tag
┃🎩 ꙰│◈/unwarn-->@tag
┃🎩 ꙰│◈/listwarn 
┃🎩 ꙰│◈/fantasmas
┃🎩 ꙰│◈/destraba
┃🎩 ꙰│◈/setpp-->ímage
└▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃  「 JUEGOS XD」
┃
mastes-->noob-->easy-->medium-->hard-->extreme-->impossible-->impossible

┃🎩 ꙰│◈/ppt-->papel-->tijera-->piedra
┃🎩 ꙰│◈/prostituto-->nombre-->@tag
┃🎩 ꙰│◈/prostituta-->nombre-->@tag
┃🎩 ꙰│◈/gay2-->nombre-->@tag 
┃🎩 ꙰│◈/lesbiana-->nombre-->@tag
┃🎩 ꙰│◈/pajero-->nombte-->@tag
┃🎩 ꙰│◈/pajera--nombre-->@tag
┃🎩 ꙰│◈/puto-->nombre-->@tag
┃🎩 ꙰│◈/puta-->nombre-->@tag
┃🎩 ꙰│◈/manco-->nombre-->@tag
┃🎩 ꙰│◈/manca-->nombre-->@tag
┃🎩 ꙰│◈/rata-->nombre-->@tag
┃🎩 ꙰│◈/love-->nombre-->@tag
┃🎩 ꙰│◈/doxear-->nombre-->@tag
┃🎩 ꙰│◈/suitpvp-->@tag
┃🎩 ꙰│◈/delttt
┃🎩 ꙰│◈/slot-->apuesta
┃🎩 ꙰│◈/pregunta-->texto
┃🎩 ꙰│◈/ttt-->nombre-->del juego
┃🎩 ꙰│◈/pista 
┃🎩 ꙰│◈/cancion
┃🎩 ꙰│◈/reto
┃🎩 ꙰│◈/verdad
┃🎩 ꙰│◈/formarpareja
┃🎩 ꙰│◈/topo-->takus
┃🎩 ꙰│◈/top-->gays
┃🎩 ꙰│◈/top-->texto
┃🎩 ꙰│◈/simi-->texto
┃🎩 ꙰│◈/acertijo 
└▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃    「 CONVERTIDORES」
┃
┃🎩 ꙰│◈/togifaud-->video
┃🎩 ꙰│◈/toimg-->sticker
┃🎩 ꙰│◈/tomp3-->video
┃🎩 ꙰│◈/tomp3-->nota-->de-->voz 
┃🎩 ꙰│◈/toptt-->video-->audio
┃🎩 ꙰│◈/tovideo-->sticker
┃🎩 ꙰│◈/tourl-->video-->imagen-->audio
┃🎩 ꙰│◈/tts-->es-->texto 
 └▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃  「 EFECTOS Y LOGOS」
┃🎩 ꙰│◈/phmaker-->opcion-->imagen 
┃🎩 ꙰│◈/logos-->efectos-->texto
┃🎩 ꙰│◈/logochristmas-->texto
┃🎩 ꙰│◈/logocorazon-->texto
┃🎩 ꙰│◈/ytcomment-->texto
┃🎩 ꙰│◈/hornycard-->@tag
┃🎩 ꙰│◈/simpcard-->@tag
┃🎩 ꙰│◈/lolice-->@tag
┃🎩 ꙰│◈/itssostupid
┃🎩 ꙰│◈/pixelar
┃🎩 ꙰│◈/blur
└▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃    「 ANIME!」
┃🎩 ꙰│◈/kaneki
┃🎩 ꙰│◈/sakura
┃🎩 ꙰│◈/nezuko
┃🎩 ꙰│◈/naruto 
┃🎩 ꙰│◈/Messi
┃🎩 ꙰│◈/cosplay
┃🎩 ꙰│◈/cristianoronaldo
┃🎩 ꙰│◈/hacker 
┃🎩 ꙰│◈/hinata
┃🎩 ꙰│◈/zaske
┃🎩 ꙰│◈/zero two
└▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃ 「 EFECTOS DE AUDIOS」
┃🎩 ꙰│◈/bass
┃🎩 ꙰│◈/blown
┃🎩 ꙰│◈/deep
┃🎩 ꙰│◈/earrape
┃🎩 ꙰│◈/fast
┃🎩 ꙰│◈/fat
┃🎩 ꙰│◈/nightcore
┃🎩 ꙰│◈/0reverse
┃🎩 ꙰│◈/robot
┃🎩 ꙰│◈/slow
┃🎩 ꙰│◈/smooth
┃🎩 ꙰│◈/tupai
└▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃   「 CHAT ANONIMO」
┃🎩 ꙰│◈/start
┃🎩 ꙰│◈/netx
┃🎩 ꙰│◈/leave
└▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃ 「 BUSCADORES」
┃🎩 ꙰│◈/stickersearch-->texto
┃🎩 ꙰│◈/stickersearch2-->texto
┃🎩 ꙰│◈/xnxxsearxh-->texto
┃🎩 ꙰│◈/google-->texto
┃🎩 ꙰│◈/letra-->texto
┃🎩 ꙰│◈/Wikipedia-->texto
┃🎩 ꙰│◈/ytsearch-->texto
└▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃ 「 INFORMACIÓN 」
┃🎩 ꙰│◈/chatgpt-->texto
┃🎩 ꙰│◈/dall-e-->texto
┃🎩 ꙰│◈/spamwa-->número--texto-->cantidad
┃🎩 ꙰│◈/tamaño-->cantidad-->imegen-->video
┃🎩 ꙰│◈/clima-->pais-->cuidad
┃🎩 ꙰│◈/encuesta-->texto1-->texto2...
┃🎩 ꙰│◈/afk-->motivo
┃🎩 ꙰│◈/ocr-->responde-->a-->imagen
┃🎩 ꙰│◈/acortar-->enlase-->link
┃🎩 ꙰│◈/calc-->operacion-->math
┃🎩 ꙰│◈/del-->mensaje
┃🎩 ꙰│◈/whatmusic-->audio
┃🎩 ꙰│◈/readqr-->imagen-->qr
┃🎩 ꙰│◈/qrcode-->texto
┃🎩 ꙰│◈/readmore-->texto1-->texto2
┃🎩 ꙰│◈/stylatext-->texto
┃🎩 ꙰│◈/traducir-->texto
┃🎩 ꙰│◈/nowa-->número 
┃🎩 ꙰│◈/covid-->pais
┃🎩 ꙰│◈/horario 
└▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃ 「 STIKERS 」
┃🎩 ꙰│◈/sticker-->enlase
┃🎩 ꙰│◈/s-->responder-->imagen-->video
┃🎩 ꙰│◈/sfull-->imegen-->video
┃🎩 ꙰│◈/emojimix-->emoji-->emoji2
┃🎩 ꙰│◈/scricle-->imagen
┃🎩 ꙰│◈/sremovebg-->imagen 
┃🎩 ꙰│◈/semoji-->imagen-->tipo-->emoji
┃🎩 ꙰│◈/attp-->texto
┃🎩 ꙰│◈/attp2-->texto
┃🎩 ꙰│◈/attp3-->texto
┃🎩 ꙰│◈/attp-->texto
┃🎩 ꙰│◈/attp4-->texto
┃🎩 ꙰│◈/attp5-->texto
┃🎩 ꙰│◈/pat-->@tag
┃🎩 ꙰│◈/slap-->@tag
┃🎩 ꙰│◈/kiss-->@tag
┃🎩 ꙰│◈/dado 
┃🎩 ꙰│◈/wm-->packname-->author
┃🎩 ꙰│◈/stickermaker-->efecto-->imagen
┃🎩 ꙰│◈/stickerfilter-->afecto-->imegen
└▭▬▭▬▭▬▭▬▭▬▭

╭▭▬▭▬▭▬▭▬▭▬▭
┃   「 OWNER DEL BOT」
┃🎩 ꙰│◈/setprefix-->prefijo
┃🎩 ꙰│◈/resetprefix
┃🎩 ꙰│◈/autoadmin
┃🎩 ꙰│◈/leavegg
┃🎩 ꙰│◈/blocklist
┃🎩 ꙰│◈/block-->@tag-->número
┃🎩 ꙰│◈/unblock-->@tag-->número
┃🎩 ꙰│◈/enable-->restrict
┃🎩 ꙰│◈/disable-->restrict
┃🎩 ꙰│◈/enable-->autoread
┃🎩 ꙰│◈/disable-->autoread
┃🎩 ꙰│◈/enable-->public
┃🎩 ꙰│◈/disable-->public
┃🎩 ꙰│◈/enable-->pconly
┃🎩 ꙰│◈/disable-->pconly
┃🎩 ꙰│◈/enable-->gconly
┃🎩 ꙰│◈/disable-->gconly
┃🎩 ꙰│◈/enable-->anticall
┃🎩 ꙰│◈/disable-->anticall
┃🎩 ꙰│◈/enable-->antiprivado
┃🎩 ꙰│◈/disable-->antiprivado
┃🎩 ꙰│◈/enable-->modejadibot
┃🎩 ꙰│◈/disable-->modejadibot
┃🎩 ꙰│◈/msg-->texto 
┃🎩 ꙰│◈/banchat
┃🎩 ꙰│◈/unbanchat
┃🎩 ꙰│◈/banuser-->@tag
┃🎩 ꙰│◈/unbanuser-->@tag
┃🎩 ꙰│◈/dardiamantes-->@tag
┃🎩 ꙰│◈/añadirxp-->@tag
┃🎩 ꙰│◈/banuser-->@tag
┃🎩 ꙰│◈/bc-->texto
┃🎩 ꙰│◈/bcchats-->texto
┃🎩 ꙰│◈/bcgc-->texto
┃🎩 ꙰│◈/bcgc2-->audio
┃🎩 ꙰│◈/bcgc2-->video
┃🎩 ꙰│◈/bcgc2-->imagen
┃🎩 ꙰│◈/bcbot-->texto
┃🎩 ꙰│◈/cleartpm
┃🎩 ꙰│◈/restart
┃🎩 ꙰│◈/update
┃🎩 ꙰│◈/banlist
┃🎩 ꙰│◈/addprem-->@tag
┃🎩 ꙰│◈/delprem-->@tag
┃🎩 ꙰│◈/listprem
┃🎩 ꙰│◈/listcdm
┃
◈ ✪𝚃𝙾𝙺𝙴𝚁-𝙱𝙾𝚃┃
└────────────────
Numero
「✪TOKER-BOT 」
wa.me/+526441187370
let buttonMessage = {
image: imagen3 ,
caption: str.trim(),
mentions: [m.sender],
footer: `*${wm}*`,
buttons: buttons,
headerType: 4,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
showAdAttribution: true,
mediaType: 'VIDEO',
mediaUrl: null,
title: '✪𝚃𝙾𝙺𝙴𝚁-𝙱𝙾𝚃 ',
body: null,
thumbnail: img,
sourceUrl: `https://youtube.com/@TokerBot`
}}}
conn.sendMessage(m.chat, buttonMessage, { quoted: m })
await conn.sendFile(m.chat, vn, 'Hola.mp3', null, m, true, { type: 'audioMessage', ptt: true})
} catch {
conn.reply(m.chat, '*El menu tiene un error y no fue posible enviarlo, reportelo al propietario del bot*', m)
}}
handler.command = /^(menu|menú|memu|memú|help|info|comandos|2help|menu1.2|ayuda|commands|commandos|m|\?)$/i
handler.exp = 50
handler.fail = null
export default handler
function clockString(ms) {
let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')}