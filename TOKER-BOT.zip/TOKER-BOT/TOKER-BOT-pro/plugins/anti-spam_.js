export async function all(m, conn) {
let texto
let user = global.db.data.users[m.sender]  
if (!m.message)
return
if (!user.antispam)
return !0
if (+new Date() > user.antispam) {
let tiempo = 60000 * 1
setTimeout(() => {
user.banned = false
texto = `[🚫] @${m.sender.split("@")[0]} *ESTAS BENEADO TEMPORALMENTE  ESPERA TU DESBANEO DURANTE *${tiempo / 1000 - 59} *ᴍɪɴᴜᴛᴏs, TRATA DE  NO HACER SPAM PARA EVITAR NUEVAMENTE SER BANEADO*`
this.sendButton(m.chat, texto, wm, null, [['🤖Menu🥷', '/menu']], m, { mentions: this.parseMention(texto) })}, tiempo)        
user.antispam = null
}}